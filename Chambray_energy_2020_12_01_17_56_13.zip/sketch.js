function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(255);
fill(0,0,255);
   ellipse(250,110,120,125);
  fill("grey");
  ellipse(250,150,200,50);
  fill("purple");
   ellipse(250,110,40,30);
}